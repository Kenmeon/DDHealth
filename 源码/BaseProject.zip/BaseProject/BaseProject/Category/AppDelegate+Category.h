//
//  AppDelegate+Category.h
//  BaseProject
//
//  Created by tarena on 15/12/16.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (Category)
/** 把各种初始化操作,固定的操作 写入到类别中 */
- (void)initializeWithApplication:(UIApplication *)application;

@end












